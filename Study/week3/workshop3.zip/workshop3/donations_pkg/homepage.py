import re


# Function to display the menu to user
def show_homepage():
    print("\n")
    print("          === DonateMe Homepage ===       ")
    print("------------------------------------------")
    print("| 1.    Login     | 2.    Register       |")
    print("------------------------------------------")
    print("------------------------------------------")
    print("| 3.    Donate    | 4.    Show Donations |")
    print("------------------------------------------")
    print("|             5. Exit                    |")
    print("------------------------------------------")
    print("\n")


# Function to donate the amount
def donate(username):
    donation_amt = input("Enter amount to donate: ")
    donation_amt = donation_amt.strip()
    if not(re.match("^[0-9]*[.]?[0-9]{1,}$", donation_amt)):
        print(
            "Only numbers are allowed (with format X.X/.X/X X-Can be set of any numbers).\n")
        return ""
    donation_string = username+" donated $"+donation_amt
    print("Thank you for your donation "+username+"\n")
    return donation_string


# Function to display list of donations and total donation
def show_donations(donations):
    if len(donations) > 0:
        print("\n--- All Donations ---\n")
        sum = 0
        for val1 in donations:
            list1 = val1.split()
            sum = sum + float(list1[2][1:])
            print(val1)
        print("Total = $"+str(sum))
        print("-----------------------\n")
    else:
        print("\nCurrently, there are no donations.\n")
