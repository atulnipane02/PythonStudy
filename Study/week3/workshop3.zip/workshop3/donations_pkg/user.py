
import re


# Function to login user into application
def login(database, username, password):
    if username.lower() not in database.keys():
        print("User "+username+" was not found in database. Please register\n")
        return ""
    elif username.lower() in database.keys() and password != database[username.lower()]:
        print("Password is incorrect for user "+username+"\n")
        return ""
    elif username.lower() in database.keys() and password == database[username.lower()]:
        print("\nWelcome "+username+"!\n")
        return username


# Function to register the user(Also checks user already exists and handle validation for username and password)
def register(database, username, password):
    username = username.strip()
    if len(username) > 10 or len(username) == 0 or not(re.match("^[a-zA-Z][a-zA-Z0-9]{1,}", username)):
        print("Username provided is incorrect. Minimum character required 1, Maximum character allowed - 10, Should start with alphabate and can be alphanumeric, should not contain special characters\n")
        return ""
    elif len(password) < 5 or not(checkCharacter(password)):
        print(
            "Password does not meet the criteria. Password should be minimum 5 characters and contain 1 upper, 1 lower, 1 digit and 1 special character among (!@#$%^&*)\n")
        return ""
    elif username.lower() not in database.keys():
        print(username+" has been registered\n")
        return username
    else:
        print(username+" already registered\n")
        return ""


# Function to check complexity of the password
def checkCharacter(password):
    special = "!@#$%^&*"
    alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    number = "0123456789"
    check1 = check2 = check3 = check4 = False
    for value in special:
        if value in password:
            check1 = True
            break
    for value in alpha:
        if value in password:
            check2 = True
            break
    for value in alpha.lower():
        if value in password:
            check3 = True
            break
    for value in number:
        if value in password:
            check4 = True
            break
    if check1 and check2 and check3 and check4:
        return True
    else:
        return False
