# Bonus Task1 - Completed
# Bonus Task2 - Completed
# Bonus Task3 - Completed
# Bonus Task4 - Completed
# Bonus Task5 - Added 2 things.
# 1. Register username should be alphanumeric only starting with alphabate.
# 2. Password complexity is added (Atleast 1 Uppercase, 1 Lower case, 1 digit and 1 special character (among !@#$%^&*) is required)


from donations_pkg import homepage as hp
from donations_pkg import user as u

database = {"admin": "password@123"}
donations = []
authorized_user = ""


while True:
    hp.show_homepage()
    userInput = input("Please select the option: ")
    userInput = userInput.strip()

    # Login functionality
    if userInput == "1":
        userNameInput = input("Enter username: ")
        passwordInput = input("Enter Password: ")
        authorized_user = u.login(database, userNameInput, passwordInput)
        #print("\nLogged in as: "+authorized_user)

    # User Register functionality
    elif userInput == "2":
        userNameInput = input("Enter username: ")
        passwordInput = input("Enter Password: ")
        authorized_user = u.register(database, userNameInput, passwordInput)
        if len(authorized_user) > 0:
            database[userNameInput.lower()] = passwordInput

    # Donate functionality
    elif userInput == "3":
        if len(authorized_user) > 0:
            donation_string = hp.donate(authorized_user)
            donations.append(donation_string)

    # Show Donations functionality
    elif userInput == "4":
        hp.show_donations(donations)
    elif userInput == "5":
        print("Goodbye\n")
        break
    else:
        print("Incorrect option selected\n")

    if len(authorized_user) == 0:
        print("\nYou must be logged in to donate.\n")
    else:
        print("Logged in as: "+authorized_user+"\n")
